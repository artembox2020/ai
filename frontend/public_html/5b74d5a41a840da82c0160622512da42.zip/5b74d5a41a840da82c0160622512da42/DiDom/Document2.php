<?php

class Document2 {
    
}