<?php

declare(strict_types=1);

namespace DiDom\Exceptions;

use Exception;

class InvalidSelectorException extends Exception
{
    //
}
